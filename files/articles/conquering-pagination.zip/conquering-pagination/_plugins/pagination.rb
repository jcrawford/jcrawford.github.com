module Jekyll

  class Pager
    
    alias_method :pagination_original_initialize,:initialize
    def initialize(config, page, all_posts, num_pages = nil)
      
      pagination_original_initialize(config, page, all_posts, num_pages)
      
      if ( page - 2 ) >= 1 and ( page + 2 ) <= total_pages
        @pager_start = page - 2
        @pager_end = page + 2
      elsif ( page - 2 ) <= 0
        @pager_start = 1
        @pager_end = 5
      elsif ( page + 2 ) >= ( total_pages - 1 )
        if page == total_pages
          @pager_start = page - 4
          @pager_end = page
        elsif page == ( total_pages - 1 )
          @pager_start = page -  3
          @pager_end = total_pages
        end
      end
    end

    alias_method :pagination_original_to_liquid, :to_liquid
    def to_liquid
      pagination_hash_original = pagination_original_to_liquid
      pagination_hash_new = { "pager_start" => @pager_start, "pager_end" => @pager_end }
      return pagination_hash_original.merge(pagination_hash_new)
    end
  end
end
